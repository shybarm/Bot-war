import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import fetch from 'node-fetch';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// ============================================
// API INTEGRATIONS
// ============================================

// Get real-time stock price
async function getStockPrice(symbol) {
  const apiKey = process.env.FINNHUB_API_KEY;
  if (!apiKey) {
    // Return mock data if no API key
    return { price: Math.random() * 500 + 100, change: Math.random() * 10 - 5 };
  }
  
  try {
    const response = await fetch(`https://finnhub.io/api/v1/quote?symbol=${symbol}&token=${apiKey}`);
    const data = await response.json();
    return {
      price: data.c, // current price
      change: data.d, // change
      changePercent: data.dp, // change percent
      high: data.h,
      low: data.l,
      open: data.o,
      previousClose: data.pc
    };
  } catch (error) {
    console.error(`Error fetching price for ${symbol}:`, error.message);
    return null;
  }
}

// Get company news
async function getCompanyNews(symbol) {
  const apiKey = process.env.NEWS_API_KEY;
  if (!apiKey) {
    return getMockNews(symbol);
  }
  
  try {
    const today = new Date().toISOString().split('T')[0];
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    
    const response = await fetch(
      `https://newsapi.org/v2/everything?q=${symbol}&from=${weekAgo}&to=${today}&sortBy=relevancy&apiKey=${apiKey}`
    );
    const data = await response.json();
    
    return data.articles?.slice(0, 10).map(article => ({
      title: article.title,
      description: article.description,
      url: article.url,
      publishedAt: article.publishedAt,
      source: article.source.name,
      sentiment: analyzeSentiment(article.title + ' ' + article.description)
    })) || [];
  } catch (error) {
    console.error(`Error fetching news for ${symbol}:`, error.message);
    return getMockNews(symbol);
  }
}

// AI-powered sentiment analysis using OpenAI
async function analyzeWithAI(symbol, news, priceData, historicalPatterns) {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return generateBasicAnalysis(symbol, news, priceData);
  }
  
  try {
    const prompt = `You are a professional stock analyst. Analyze ${symbol} and provide a trading recommendation.

Current Data:
- Price: $${priceData.price}
- Change: ${priceData.changePercent}%
- Recent News Headlines: ${news.map(n => n.title).join('; ')}

Historical Patterns:
${historicalPatterns.slice(0, 3).map(p => `- ${p.pattern}: ${p.outcome > 0 ? 'Positive' : 'Negative'} outcome`).join('\n')}

Provide a JSON response with:
{
  "signal": "BUY" | "SELL" | "HOLD",
  "confidence": 0-100,
  "reasoning": "brief explanation",
  "targetPrice": number,
  "stopLoss": number,
  "timeHorizon": "short" | "medium" | "long"
}`;

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: 'gpt-4',
        messages: [
          { role: 'system', content: 'You are an expert stock analyst. Always respond with valid JSON only.' },
          { role: 'user', content: prompt }
        ],
        temperature: 0.7,
        max_tokens: 500
      })
    });
    
    const data = await response.json();
    const analysis = JSON.parse(data.choices[0].message.content);
    return analysis;
  } catch (error) {
    console.error('AI analysis error:', error.message);
    return generateBasicAnalysis(symbol, news, priceData);
  }
}

// Basic rule-based analysis (fallback)
function generateBasicAnalysis(symbol, news, priceData) {
  const sentimentScore = news.reduce((sum, n) => sum + n.sentiment, 0) / news.length || 0;
  const priceChange = priceData.changePercent || 0;
  
  let signal = 'HOLD';
  let confidence = 50;
  
  if (sentimentScore > 0.3 && priceChange > 2) {
    signal = 'BUY';
    confidence = 75;
  } else if (sentimentScore > 0.1 && priceChange > 0) {
    signal = 'BUY';
    confidence = 65;
  } else if (sentimentScore < -0.3 && priceChange < -2) {
    signal = 'SELL';
    confidence = 75;
  } else if (sentimentScore < -0.1 && priceChange < 0) {
    signal = 'SELL';
    confidence = 65;
  }
  
  return {
    signal,
    confidence,
    reasoning: `Based on sentiment (${sentimentScore.toFixed(2)}) and price trend (${priceChange.toFixed(2)}%)`,
    targetPrice: priceData.price * (signal === 'BUY' ? 1.05 : 0.95),
    stopLoss: priceData.price * (signal === 'BUY' ? 0.95 : 1.05),
    timeHorizon: Math.abs(priceChange) > 3 ? 'short' : 'medium'
  };
}

// Simple sentiment analysis
function analyzeSentiment(text) {
  const positive = ['surge', 'growth', 'profit', 'beat', 'strong', 'record', 'upgrade', 'bullish', 'gain', 'rise'];
  const negative = ['drop', 'loss', 'miss', 'weak', 'concern', 'downgrade', 'bearish', 'fall', 'decline'];
  
  const lowerText = text.toLowerCase();
  let score = 0;
  
  positive.forEach(word => {
    if (lowerText.includes(word)) score += 0.1;
  });
  
  negative.forEach(word => {
    if (lowerText.includes(word)) score -= 0.1;
  });
  
  return Math.max(-1, Math.min(1, score));
}

// Mock data for development
function getMockNews(symbol) {
  const templates = [
    { title: `${symbol} reports strong Q4 earnings`, sentiment: 0.8 },
    { title: `Analysts upgrade ${symbol} to Buy`, sentiment: 0.6 },
    { title: `${symbol} announces new product line`, sentiment: 0.5 },
    { title: `${symbol} faces regulatory scrutiny`, sentiment: -0.4 },
    { title: `Market volatility affects ${symbol}`, sentiment: -0.2 }
  ];
  
  return templates.map(t => ({
    ...t,
    description: `News about ${symbol}`,
    url: '#',
    publishedAt: new Date().toISOString(),
    source: 'Mock News'
  }));
}

// In-memory storage for patterns (use database in production)
const patterns = new Map();

function learnFromOutcome(symbol, signal, priceAtSignal, priceAfter) {
  const outcome = ((priceAfter - priceAtSignal) / priceAtSignal) * 100;
  const pattern = { signal, priceAtSignal, priceAfter, outcome, timestamp: Date.now() };
  
  if (!patterns.has(symbol)) {
    patterns.set(symbol, []);
  }
  
  patterns.get(symbol).push(pattern);
  
  // Keep only last 50 patterns per symbol
  if (patterns.get(symbol).length > 50) {
    patterns.get(symbol).shift();
  }
  
  return pattern;
}

// ============================================
// API ENDPOINTS
// ============================================

// Get analysis for a specific stock
app.get('/api/analyze/:symbol', async (req, res) => {
  try {
    const { symbol } = req.params;
    
    console.log(`📊 Analyzing ${symbol}...`);
    
    // Fetch real-time data
    const [priceData, news] = await Promise.all([
      getStockPrice(symbol),
      getCompanyNews(symbol)
    ]);
    
    if (!priceData) {
      return res.status(500).json({ error: 'Failed to fetch stock data' });
    }
    
    // Get historical patterns
    const historicalPatterns = patterns.get(symbol) || [];
    
    // AI analysis
    const analysis = await analyzeWithAI(symbol, news, priceData, historicalPatterns);
    
    res.json({
      symbol,
      price: priceData.price,
      change: priceData.change,
      changePercent: priceData.changePercent,
      news: news.slice(0, 5),
      analysis,
      historicalAccuracy: calculateAccuracy(historicalPatterns)
    });
  } catch (error) {
    console.error('Analysis error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get analysis for multiple stocks
app.post('/api/analyze-batch', async (req, res) => {
  try {
    const { symbols } = req.body;
    
    const analyses = await Promise.all(
      symbols.map(async (symbol) => {
        const [priceData, news] = await Promise.all([
          getStockPrice(symbol),
          getCompanyNews(symbol)
        ]);
        
        if (!priceData) return null;
        
        const historicalPatterns = patterns.get(symbol) || [];
        const analysis = await analyzeWithAI(symbol, news, priceData, historicalPatterns);
        
        return {
          symbol,
          price: priceData.price,
          change: priceData.changePercent,
          signal: analysis.signal,
          confidence: analysis.confidence,
          reasoning: analysis.reasoning
        };
      })
    );
    
    res.json(analyses.filter(a => a !== null));
  } catch (error) {
    console.error('Batch analysis error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Record outcome for learning
app.post('/api/learn', async (req, res) => {
  try {
    const { symbol, signal, priceAtSignal, priceAfter } = req.body;
    
    const pattern = learnFromOutcome(symbol, signal, priceAtSignal, priceAfter);
    
    res.json({
      success: true,
      pattern,
      totalPatterns: patterns.get(symbol)?.length || 0
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get market overview
app.get('/api/market-overview', async (req, res) => {
  try {
    const symbols = ['AAPL', 'MSFT', 'GOOGL', 'AMZN', 'NVDA', 'TSLA', 'META', 'AMD'];
    
    const overview = await Promise.all(
      symbols.map(async (symbol) => {
        const priceData = await getStockPrice(symbol);
        return priceData ? {
          symbol,
          price: priceData.price,
          change: priceData.changePercent
        } : null;
      })
    );
    
    res.json(overview.filter(o => o !== null));
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    apis: {
      finnhub: !!process.env.FINNHUB_API_KEY,
      newsApi: !!process.env.NEWS_API_KEY,
      openai: !!process.env.OPENAI_API_KEY
    }
  });
});

// Helper function
function calculateAccuracy(patterns) {
  if (patterns.length === 0) return 0;
  
  const correct = patterns.filter(p => {
    if (p.signal === 'BUY') return p.outcome > 0;
    if (p.signal === 'SELL') return p.outcome < 0;
    return Math.abs(p.outcome) < 2; // HOLD within 2%
  }).length;
  
  return (correct / patterns.length * 100).toFixed(1);
}

// Start server
app.listen(PORT, () => {
  console.log(`🚀 AI Trading Server running on port ${PORT}`);
  console.log(`📊 APIs configured:`);
  console.log(`   - Finnhub: ${process.env.FINNHUB_API_KEY ? '✅' : '❌ (using mock data)'}`);
  console.log(`   - NewsAPI: ${process.env.NEWS_API_KEY ? '✅' : '❌ (using mock data)'}`);
  console.log(`   - OpenAI: ${process.env.OPENAI_API_KEY ? '✅' : '❌ (using basic analysis)'}`);
  console.log(`\n🌐 Server ready at http://localhost:${PORT}`);
});

export default app;
